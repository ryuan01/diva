//Title: 		InspectionReporter
//Description: 	Produces a functional Graphical Interface for creating inspection reports
//Dependancies:	This module requires a canvas element and a div, pass the tag id of both of these elements to the constructor
//Date:			April 2nd, 2016
//Author:		Alex Daniels
//License:		Free and OpenSource

//CREATES AN INSPECTIONREPORTER MODULE (which contains a  CanvasManager, CoordinatesManager and CommentsManager)
function InspectionReporter(canvasID,divID,imagePath) {

//------------------------------------------------PUBLIC INTERFACE-----------------------------------------------------------

	this.state = "CLOSED", //States: CLOSED, EDITING, DISPLAY

	//Starts editing mode with a new Report
	this.newReport = function() {
		if (this.state === "CLOSED") {
			this.state =	 "EDITING";
			this.CanvasManager.openCanvas();
			this.CanvasManager.renderCanvas(this.CoordinatesManager.coordinates);
			this.startClickListener();
		}
	},

	//Called while in editing mode to finalize the report
	//After calling this the InspectionReporter will move to it's initial state and return a Report Object
	this.saveReport = function() {
		if (this.state === "EDITING") {
			var report = {};
				report.coordinates = this.CoordinatesManager.coordinates;
				report.comments = this.CommentsManager.getCommentsArray();
			var reportObject = this.makeReport(report);
			this.clear();
			this.CanvasManager.closeCanvas();
			this.stopClickListener();
			this.state = "CLOSED";
			var reportString = JSON.stringify(reportObject);
			return reportString;
		}
	},

	//Displays the coordinates and comments of the given report ontop of the canvas and report image - Not editable 
	this.displayReport = function(reportString) {
		if (this.state === "CLOSED") {
			this.state = "DISPLAY";
			//Turn reportString into reportObject
			var reportObject = JSON.parse(reportString);
			
			//Open the canvas
			this.CanvasManager.openCanvas();
			
			//set up environment
			this.setUpEnvironment(reportObject);
			
			//inject values
			this.injectComments(reportObject);
			
			//render the Canvas
			this.CanvasManager.openCanvas();
			this.CanvasManager.renderCanvas(this.CoordinatesManager.coordinates);
		}
	},
	
	this.close = function() {
		if (this.state === "EDITING") {
			this.clear();
			this.stopClickListener();
			this.CanvasManager.closeCanvas();
		}
		else if (this.state === "DISPLAY") {
			this.clear();
			this.CanvasManager.closeCanvas();
		}
		this.state="CLOSED";
	},

	//Undoes the last action while in editing mode
	this.removeLastCoordinate = function() {
		if (this.state === "EDITING") {
			this.CoordinatesManager.removeLastCoordinates();
			this.CanvasManager.renderCanvas(this.CoordinatesManager.coordinates);
			this.CommentsManager.removeLastCommentBox();
		}
	},

	//Sets the entire InspectionReporter and all it's containing objects to it's inital state
	this.clear = function() {
		if (this.state === "EDITING" || this.state === "DISPLAY") {
			this.CommentsManager.clear();
			this.CoordinatesManager.clear();
			this.CanvasManager.renderCanvas(this.CoordinatesManager.coordinates);
		}
	},

//-------------------------------------------------------Canvas Manager--------------------------------------------//
	//The CanvasManager renders to the canvas the image and any coordinates that are in the Coordinates Manager. 
	//It also manages the expansion and compression on the canvas.
	this.CanvasManager = {

		//Canvas holds the canvas element, ctx holds the canvas's drawing contex while image holds the photo of the report to draw ontop of
    	canvas : document.getElementById(canvasID),
    	ctx : 	canvas.getContext('2d'),
    	image : new Image(),

		//returns the position of the given mouse event
	    getPosition : function(event) {
	  		var x = event.x;
	  		var y = event.y;
	  		x -= this.canvas.offsetLeft;
	  		y -= this.canvas.offsetTop;
			return {x,y};
		},

		//sets the vancas to a set size, making it visible to the user
	    openCanvas : function() {
			this.canvas.width=750;		
			this.canvas.height=475;
		},
	
		//Sets the canvas size to 0,0 - effectivly making it invisible
	    closeCanvas : function() {
			this.canvas.width=0;		
			this.canvas.height=0;
		},

		//Draws the report image first and then prints all the coordinates ontop of the image
	    renderCanvas : function(coordinates) {
			this.ctx.drawImage(this.image,0,0,this.image.width,this.image.height,0,0,this.canvas.width,this.canvas.height);
			this.renderCoordinates(coordinates);
		},
		
		renderCoordinates : function(coordinates) {
			for (var i = 0; i < coordinates.length; i++) {
				currentCoordinates = coordinates[i];
				var x = currentCoordinates.x;
				var y = currentCoordinates.y;
				this.ctx.fillRect(x-6,y-6,6,6);
				this.ctx.font='17px Arial'
				this.ctx.fillText(i+1,x,y);
			}
		}
	},

	//------------------------------------------------------Coordinates Manager-----------------------------------------//
	//The CoordinatesManager buffers the coodinates in an array of 2 index arrays and it can also be used to remove one of it's buffered coordinates. 
	//The first index of each array is the x coordinate and the second index of each array is the y coordinate
	this.CoordinatesManager = {
	
		//Holds all the coordinates of a report while it's being filled out
		coordinates : [],

		//Adds the given coordinates to the coordinates array
		addCoordinates : function(co) {
			this.coordinates.push(co);
		},

		//Removes the last coordinates added to the array
   		removeLastCoordinates : function() {
			this.coordinates.pop();
		},

		//Resets the array to its inital value
    	clear : function() {
			this.coordinates = [];
		}
	},

	//-------------------------------------------------------Comments Manager-------------------------------------------//
	//Buffers the comments into an array of comments. One comment for each coordinate
	//For every click, a new text feild is added to the reportDIV
	this.CommentsManager =  {
	
		//The reportDiv holds an area to place text boxes for report comments. Counter keeps track of how many text boxes their are
		counter : 0,
    	reportDiv : document.getElementById(divID),
		
		//Adds a comment box to the report div
    	addCommentBox : function() {
			this.counter++;
			var output = "";
			for (var i = 0; i < this.counter; i++) {
				output+= (i+1) + ") "+"<input id='reportComment" + i + "' type='text'></input><br>";
			}
			this.reportDiv.innerHTML=output;
		},

		//Lowers the counter by two and calls addcommentbox - effectivly removing 1 comment box
  		removeLastCommentBox : function() {
			this.counter--;
			this.counter--;
			this.addCommentBox();
		},

		//This will load all the comments in the div into an array and return the array
 	 	getCommentsArray : function() {
			var commentsArray = [];
			for (var i = 0; i < this.counter; i++) {
				var currentId = "reportComment" + i;
				var currentComment = document.getElementById(currentId).value;
				commentsArray.push(currentComment);
			}
			return commentsArray;
		},

		//Resets the CommentManagers instance variables to their initial state
    	clear : function() {
			this.reportDiv.innerHTML="";
			this.comments = [];
			this.counter = 0;
			
   		}
	},

//------------------------------------------------Mouse Manager---------------------------------------------------//
	//Adds an event listener to the mouse
	this.callBackHandler = null,
	
   	this.startClickListener = function() {
		
		var com = this.CommentsManager;
		var coo = this.CoordinatesManager;
		var can = this.CanvasManager;
		
		function callBackHandler() {
			var coordinates = can.getPosition(event);
			com.addCommentBox();
			coo.addCoordinates(coordinates);
			can.renderCanvas(coo.coordinates);
		}
		this.callBackHandler = callBackHandler;
		this.CanvasManager.canvas.addEventListener('mousedown', callBackHandler, false);
	},
		
	//Removes the mouse event listener
    this.stopClickListener = function(clickCallBack) {
		this.CanvasManager.canvas.removeEventListener('mousedown', this.callBackHandler);
	},
	
	this.makeReport = function(report) {
		var reportObject = {};
			reportObject.incidentUnits = [];
			for (var i = 0; i < report.coordinates.length; i++) {
				var currentCoordinates = report.coordinates[i];
				var currentComment = report.comments[i];
				var incidentUnit = {};
				incidentUnit.x = currentCoordinates.x;
				incidentUnit.y = currentCoordinates.y;
				incidentUnit.comment = currentComment;
				reportObject.incidentUnits.push(incidentUnit);
			}
		return reportObject
	},
	
	this.setUpEnvironment = function(reportObject) {
		var array = reportObject.incidentUnits;
		var comments = [];
		for (var i = 0; i < array.length; i++) {
			
			//Get current incidentUnit;
			var unit = array[i];
			
			//Set up coodinates
			this.CoordinatesManager.addCoordinates(unit);
			this.CommentsManager.addCommentBox(unit.comment);
		}
	},
	
	this.injectComments = function(reportObject) {
		var array = reportObject.incidentUnits;
		for (var i = 0; i < array.length; i++) {
			var currentId = "reportComment" + i;
			var unit = array[i];
			var currentTextBox = document.getElementById(currentId);
			var currentComment = unit.comment;
			currentTextBox.value=currentComment;
		}
	},
	
	//Initializes the image of the report
	this.CanvasManager.image.src=imagePath;
}
